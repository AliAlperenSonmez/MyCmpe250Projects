

public class Reindeer extends Carrier{
	
	private int ID;
	private int capacity;
	private char type;
	
	
	public Reindeer(int ID, int capacity, char type) {
		super(ID,capacity,type);
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public char getType() {
		return type;
	}
	
	public void useCapacity(int amount) {
		capacity -= amount;
	}
	
	public int getID() {
		return ID;
	}
	
}
