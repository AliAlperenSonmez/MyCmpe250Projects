import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.*;

public class project4main {

	public static void main(String[] args) throws FileNotFoundException {
		
		//Taking input
		Locale.setDefault(new Locale("en", "US"));
		Scanner in = new Scanner(new File(args[0]));
		PrintStream out = new PrintStream(new File(args[1]));
		
		Vertice source = new Vertice(0,0);
		Vertice sink = new Vertice(-1,3);
		
		int nofGifts = 0;
		
		ArrayList<Carrier> carriers = new ArrayList<Carrier>();
		
		ArrayList<Train> greenTrains = new ArrayList<Train>();
		int nofGreenTrains =  in.nextInt();
		
		for (int i=0; i<nofGreenTrains; i++) {
			int ID = i+1;
			int capacity = in.nextInt();
			Train t = new Train(ID, capacity,'g');
			greenTrains.add(t);
			carriers.add(t);
			t.getNeighbours().put(sink,capacity);
		}
		
		
		int nofRedTrains = in.nextInt();
		ArrayList<Train> redTrains = new ArrayList<Train>();
		
		for (int i=0; i<nofRedTrains; i++) {
			int ID = nofGreenTrains+i+1;
			int capacity = in.nextInt();
			Train t = new Train(ID, capacity,'r');
			redTrains.add(t);
			carriers.add(t);
			t.getNeighbours().put(sink,capacity);
		}
		
		ArrayList<Reindeer> greenReindeers = new ArrayList<Reindeer>();
		int nofGreenReindeers =  in.nextInt();
		
		for (int i=0; i<nofGreenReindeers; i++) {
			int ID = nofGreenTrains+i+nofRedTrains+1;
			int capacity = in.nextInt();
			Reindeer r = new Reindeer(ID, capacity,'g');
			greenReindeers.add(r);
			carriers.add(r);
			r.getNeighbours().put(sink,capacity);
		}
		
		
		int nofRedReindeers = in.nextInt();
		ArrayList<Reindeer> redReindeers = new ArrayList<Reindeer>();
		
		for (int i=0; i<nofRedReindeers; i++) {
			int ID = nofGreenTrains+i+nofRedTrains+nofGreenReindeers+1;
			int capacity = in.nextInt();
			Reindeer r = new Reindeer(ID, capacity,'r');
			redReindeers.add(r);
			carriers.add(r);
			r.getNeighbours().put(sink,capacity);
		}
		
		ArrayList<Bag> bags = new ArrayList<Bag>();
		int nofBags = in.nextInt();
		
		for(int i=nofGreenTrains+nofRedTrains+nofGreenReindeers+nofRedReindeers; 
				i<nofBags+nofGreenTrains+nofRedTrains+nofGreenReindeers+nofRedReindeers; i++) {
			String type = in.next();
			int load = in.nextInt();
			Bag b = new Bag(i+1,type,load);
			bags.add(b);
			source.getNeighbours().put(b, load);
			nofGifts+=b.getAmount();
		}
		//
		
		
		//Constructing the edges between bags and carriers
		for (Bag b:bags) {
			if(b.getType().equals("a")) {
				for (Carrier c: carriers) {
					b.getNeighbours().put(c, 1);
				}
			}
			
			else if (b.getType().equals("b")) {
				
				for (Train t: greenTrains) {
					b.getNeighbours().put(t, b.getAmount());
				}
				
				for (Reindeer r: greenReindeers) {
					b.getNeighbours().put(r, b.getAmount());
				}
					
			}
			
			else if (b.getType().equals("c")) {
				
				for (Train t: redTrains) {
					b.getNeighbours().put(t, b.getAmount());
				}
				
				for (Reindeer r: redReindeers) {
					b.getNeighbours().put(r, b.getAmount());
				}
				
			}
			
			else if (b.getType().equals("d")) {
				
				for (Train t: redTrains) {
					b.getNeighbours().put(t, b.getAmount());
				}
				
				for (Train t: greenTrains) {
					b.getNeighbours().put(t, b.getAmount());
				}
				
			}
			
			else if (b.getType().equals("e")) {
				
				for (Reindeer r: redReindeers) {
					b.getNeighbours().put(r, b.getAmount());
				}
				
				for (Reindeer r: greenReindeers) {
					b.getNeighbours().put(r, b.getAmount());
				}
				
			}
			
			else if (b.getType().equals("ab")) {
				
				for (Train t: greenTrains) {
					b.getNeighbours().put(t, 1);
				}
				
				for (Reindeer r: greenReindeers) {
					b.getNeighbours().put(r, 1);
				}
				
			}
			
			else if (b.getType().equals("ac")) {
				
				for (Train t: redTrains) {
					b.getNeighbours().put(t, 1);
				}
				
				for (Reindeer r: redReindeers) {
					b.getNeighbours().put(r, 1);
				}
				
			}
			
			else if (b.getType().equals("ad")) {
				
				for (Train t: redTrains) {
					b.getNeighbours().put(t, 1);
				}
				
				for (Train t: greenTrains) {
					b.getNeighbours().put(t, 1);
				}
				
			}
			
			else if (b.getType().equals("ae")) {
				
				for (Reindeer r: redReindeers) {
					b.getNeighbours().put(r, 1);
				}
				
				for (Reindeer r: greenReindeers) {
					b.getNeighbours().put(r, 1);
				}
				
			}
			
			else if (b.getType().equals("bd")) {
				
				for (Train t: greenTrains) {
					b.getNeighbours().put(t, b.getAmount());
				}
			
			}
			
			else if (b.getType().equals("be")) {
				
				for (Reindeer r: greenReindeers) {
					b.getNeighbours().put(r, b.getAmount());
				}
				
			}
			
			else if (b.getType().equals("cd")) {
				
				for (Train t: redTrains) {
					b.getNeighbours().put(t, b.getAmount());
				}
				
			}
			
			else if (b.getType().equals("ce")) {
				
				for (Reindeer r: redReindeers) {
					b.getNeighbours().put(r, b.getAmount());
				}
				
			}
			
			else if (b.getType().equals("abd")) {
				
				for (Train t: greenTrains) {
					b.getNeighbours().put(t, 1);
				}
				
			}
			
			else if (b.getType().equals("abe")) {
				
				for (Reindeer r: greenReindeers) {
					b.getNeighbours().put(r, 1);
				}
				
			}
			
			else if (b.getType().equals("acd")) {
				
				for (Train t: redTrains) {
					b.getNeighbours().put(t, 1);
				}
				
			}
			
			else if (b.getType().equals("ace")) {
				
				for (Reindeer r: redReindeers) {
					b.getNeighbours().put(r, 1);
				}
				
			}
		}
		//
		
		System.out.println("Hello");
		
		int maxFlow = 0;
		int newEdge;
		int minEdge = Integer.MAX_VALUE;
		Dfs dfs = new Dfs();
		ArrayList<Vertice> path = new ArrayList<Vertice>();
		
		while(dfs.search(source, sink)) {
			Vertice v = sink;
			while (v.getID()!=0) {
				path.add(v);
				if (v.parent.getNeighbours().get(v)<minEdge) {
					minEdge = v.parent.getNeighbours().get(v);
				}
				v = v.parent;
			}
			path.add(source);
			
			maxFlow+=minEdge;
			
			for (Vertice ver:path) {
				if (ver.getID()!=0) {
					
					newEdge = ver.parent.getNeighbours().get(ver)-minEdge;
					
					// Updating edge
					if (newEdge>=0) {
					ver.parent.getNeighbours().put(ver, newEdge);
					}
					
					// Adding reverse edge
					if(ver.getNeighbours().containsKey(ver.parent)) {
						ver.getNeighbours().put(ver.parent, ver.getNeighbours().get(ver.parent)+minEdge);
					}
					else {
						ver.getNeighbours().put(ver.parent, minEdge);
					}
					
				}
			}
			minEdge = Integer.MAX_VALUE;
			dfs = new Dfs();
			System.out.println(maxFlow);
		}
		
		
		
		
		out.println(nofGifts-maxFlow);

		
		
	}
}
