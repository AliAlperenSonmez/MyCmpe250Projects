import java.util.HashMap;

public class Vertice implements Comparable<Vertice>{
		
		private int ID;
		private int level;
		public boolean visited = false;
		public Vertice parent = null;
		private HashMap<Vertice,Integer> neighbours = new HashMap<Vertice,Integer>();
		
		public Vertice(int ID, int level) {
			this.ID = ID;
			this.level = level;
		}
		
		public HashMap<Vertice, Integer> getNeighbours() {
			return neighbours;
		}
		
		public int getID() {
			return ID;
		}
		
		public int getLevel() {
			return level;
		}

		@Override
		public int compareTo(Vertice o) {
			if (this.getNeighbours().size()<o.getNeighbours().size()) {
				return -1;
			}
			else {
				return 1;
			}
		}
}
