

public class Train extends Carrier {
	
	private int ID;
	private int capacity;
	private char type;
	
	public Train(int ID, int capacity, char type) {
		super(ID,capacity,type);
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public char getType() {
		return type;
	}
	
	public void useCapacity(int amount) {
		capacity -= amount;
	}
	
	public int getID() {
		return ID;
	}
	
}
